from fastapi import FastAPI, Query
import httpx
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")
YOUTUBE_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"

@app.get("/search")
async def search_youtube(q: str = Query(..., description="Search query term")):
    params = {
        "part": "snippet",
        "q": q,
        "key": YOUTUBE_API_KEY,
        "type": "video",
        "maxResults": 10,
        "order": "date"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(YOUTUBE_SEARCH_URL, params=params)

    if response.status_code != 200:
        return {"error": "Failed to fetch data from YouTube API"}

    items = response.json().get("items", [])

    videos = [
        {
            "title": item["snippet"]["title"],
            "video_url": f"https://www.youtube.com/watch?v={item['id']['videoId']}",
            "published_at": item["snippet"]["publishedAt"]
        }
        for item in items
    ]

    return {"query": q, "results": videos}
